package servlet;

import bean.vo.GoodsVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.AutowireCapableBeanFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;
import service.GoodsService;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@Controller
@WebServlet("/addGoods")
public class AddGoodsServlet extends HttpServlet {

    @Autowired
    GoodsService goodsService;

    @Override
    public void init(ServletConfig config) throws ServletException {
        super.init(config);
        WebApplicationContext wac = WebApplicationContextUtils.getWebApplicationContext(getServletContext());
        AutowireCapableBeanFactory factory = wac.getAutowireCapableBeanFactory();
        factory.autowireBean(this);
    }

    @Override
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        String goodsName = request.getParameter("goodsName");
        String priceStr = request.getParameter("price");

        String rstPage = "getAllGoods";
        try {
            Float price = Float.parseFloat(priceStr);
            GoodsVo newGoods = new GoodsVo();
            newGoods.setGoodsName(goodsName);
            newGoods.setPrice(price);

            Integer rst = goodsService.saveGoods(newGoods);

            if (rst != 1) {
                request.setAttribute("resultMessage", "添加商品出错!");
            } else {
                request.setAttribute("resultMessage", "添加商品成功!");
            }
        } catch (NumberFormatException e) {
            request.setAttribute("resultMessage", "价格格式不正确!");
        }

        request.getRequestDispatcher(rstPage).forward(request, response);
    }

    @Override
    public void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doGet(req, resp);
    }
}
