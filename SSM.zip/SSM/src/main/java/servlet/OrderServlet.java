package servlet;

import bean.vo.Order;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.context.support.SpringBeanAutowiringSupport;
import service.OrderService;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet(urlPatterns = {"/addOrder", "/deleteOrder", "/showOrders"})
public class OrderServlet extends HttpServlet {

    @Autowired
    private OrderService orderService;

    @Override
    public void init(ServletConfig config) throws ServletException {
        super.init(config);
        SpringBeanAutowiringSupport.processInjectionBasedOnServletContext(this, config.getServletContext());
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String uri = req.getRequestURI();
        if (uri.endsWith("addOrder")) {
            addOrder(req, resp);
        } else if (uri.endsWith("deleteOrder")) {
            deleteOrder(req, resp);
        } else if (uri.endsWith("showOrders")) {
            showOrders(req, resp);
        }
    }

    private void addOrder(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        Order order = new Order();
        orderService.addOrder(order);
        resp.sendRedirect("showOrders");
    }

    private void deleteOrder(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        int orderId = Integer.parseInt(req.getParameter("orderId"));
        orderService.deleteOrder(orderId);
        resp.sendRedirect("showOrders");
    }

    private void showOrders(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        List<Order> orders = orderService.getAllOrders();
        req.setAttribute("orders", orders);
        req.getRequestDispatcher("orders.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doGet(req, resp);
    }
}

