package service;

import bean.vo.Item;
import java.util.List;

public interface ItemService {
    void addToCart(Integer goodsId, int quantity);
    void updateItem(Integer itemId, int quantity);
    void deleteItem(Integer itemId);
    void clearCart();
    List<Item> getCartItems();
}

