package service;

import bean.vo.GoodsVo;
import bean.vo.Item;
import dao.ItemDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service("itemService")
public class ItemServiceImpl implements ItemService {

    @Autowired
    private ItemDao itemDao;

    @Autowired
    private GoodsService goodsService;

    @Override
    public void addToCart(Integer goodsId, int quantity) {
        GoodsVo goods = goodsService.getGoodsById(goodsId);
        Item item = new Item(goods, quantity);
        itemDao.addItem(item);
    }

    @Override
    public void updateItem(Integer itemId, int quantity) {
        Item item = itemDao.getItemById(itemId);
        if (item != null) {
            item.setQuantity(quantity);
            itemDao.updateItem(item);
        }
    }

    @Override
    public void deleteItem(Integer itemId) {
        itemDao.deleteItem(itemId);
    }

    @Override
    public void clearCart() {
        // This is not efficient for large carts, but will work for this example.
        // A better implementation would be a deleteAllItems method in the DAO.
        List<Item> items = getCartItems();
        for (Item item : items) {
            itemDao.deleteItem(item.getItemId());
        }
    }

    @Override
    public List<Item> getCartItems() {
        return itemDao.getAllItems();
    }
}

