package service;

import bean.vo.Item;

import java.util.ArrayList;

public interface CartService {
    public ArrayList<Item> addToCart(ArrayList<Item> cart, Integer goodsId, int quantity);
    public ArrayList<Item> update(ArrayList<Item> cart, Integer goodsId, int quantity);
    public ArrayList<Item> delete(ArrayList<Item> cart, Integer goodsId);
    public ArrayList<Item> getCart();
