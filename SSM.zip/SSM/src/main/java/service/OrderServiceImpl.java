package service;

import bean.vo.Item;
import bean.vo.Order;
import dao.ItemDao;
import dao.OrderDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.List;

@Service("orderService")
public class OrderServiceImpl implements OrderService {

    @Autowired
    private OrderDao orderDao;

    @Autowired
    private ItemDao itemDao;

    @Autowired
    private ItemService itemService;

    @Override
    @Transactional
    public void addOrderFromCart() {
        List<Item> cartItems = itemService.getCart();
        if (cartItems == null || cartItems.isEmpty()) {
            return; // 购物车为空，不创建订单
        }

        Order order = new Order();
        order.setOrderTime(new Date());
        order.setItems(cartItems);

        // 1. 插入订单记录，并获取生成的 orderId
        orderDao.addOrder(order);

        // 2. 更新购物车中每个 Item 的 orderId
        for (Item item : cartItems) {
            item.setOrderId(order.getOrderId());
            itemDao.updateItemOrderId(item);
        }

        // 3. 清空购物车
        itemService.clearCart();
    }

    @Override
    public List<Order> getAllOrders() {
        return orderDao.getAllOrders();
    }

    @Override
    @Transactional
    public void deleteOrder(Integer orderId) {
        // 在删除订单之前，先删除与该订单关联的所有项目
        itemDao.deleteItemsByOrderId(orderId);
        // 然后删除订单本身
        orderDao.deleteOrder(orderId);
    }
}
