package service;

import bean.vo.Order;
import java.util.List;

public interface OrderService {
    void addOrder(Order order);
    void deleteOrder(int orderId);
    Order getOrderById(int orderId);
    List<Order> getAllOrders();
}

