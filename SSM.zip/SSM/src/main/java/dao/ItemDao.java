package dao;

import bean.vo.Item;
import java.util.List;

public interface ItemDao {
    void addItem(Item item);
    void updateItem(Item item);
    void deleteItem(int itemId);
    Item getItemById(int itemId);
    List<Item> getAllItems();
    // 在 ItemDao 接口中添加以下方法
    void updateItemOrderId(Item item);
    void deleteItemsByOrderId(Integer orderId);
    List<Item> getItemsByOrderId(Integer orderId);
}

