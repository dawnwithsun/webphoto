package bean.vo;

import lombok.Data;

@Data
public class Item {
	private Integer itemId;
	private GoodsVo goods;
	private Integer goodsId;
	private Integer quantity;
	private Integer orderId;

	// 构造方法
	public Item() {}

	public Item(GoodsVo goods, int quantity) {
		this.goods = goods;
		this.goodsId = goods.getGoodsId();
		this.quantity = quantity;
	}

	// Getter 和 Setter 方法
	public Integer getItemId() { return itemId; }
	public void setItemId(Integer itemId) { this.itemId = itemId; }

	public GoodsVo getGoods() { return goods; }
	public void setGoods(GoodsVo goods) {
		this.goods = goods;
		if(goods != null) this.goodsId = goods.getGoodsId();
	}

	public Integer getGoodsId() { return goodsId; }
	public void setGoodsId(Integer goodsId) { this.goodsId = goodsId; }

	public Integer getQuantity() { return quantity; }
	public void setQuantity(Integer quantity) { this.quantity = quantity; }

	public Integer getOrderId() { return orderId; }
	public void setOrderId(Integer orderId) { this.orderId = orderId; }
}
