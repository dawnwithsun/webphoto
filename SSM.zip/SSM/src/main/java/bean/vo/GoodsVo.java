package bean.vo;

import lombok.Data;

public class GoodsVo {
    private Integer goodsId;
    private String goodsName;
    private Float price;
    private Integer salesVolume;
    private setGoodsId(int goodsId)
}
